console.log('📚 [storyContent] 日本語版ストーリーコンテンツ（音声切り替えデバッグ強化版）読み込み開始...');

const storyContent = [
    // ========== シーン1：覚醒 ==========
    {
        text: "<span class='emphasis'>第一話『覚醒』</span>",
        bg: "bg1",
        speed: 0.1,
        audio: "mushi.m4a",
        lines: 0,
        scene: "scene1",
        sceneTitle: "覚醒"
    },
    {
        text: "満月が石段を照らす古い神社の夜・・・。\n風化した鳥居の向こう、苔むした石畳に天から一筋の光が伸びていた。",
        bg: "bg1",
        speed: 0.3,
        audio: "mushi.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "その光が照らし出したのは、そこで眠る小さな影。",
        bg: "bg1",
        speed: 0.4,
        audio: "mushi.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "運命に導かれるように、一匹の犬がこの神社に迷い込み眠っていた。",
        bg: "bg1",
        speed: 0.4,
        audio: "mushi.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "その名もRYOCHAN。\nミニチュアシュナウザーだった。",
        bg: "bg1",
        speed: 0.4,
        audio: "mushi.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "小さな武者鎧に身を包んだその姿は、月明かりを受けてほのかに光っていた・・・。",
        bg: "bg1",
        speed: 0.4,
        audio: "mushi.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "すると、風は吹いていないはずなのに、桜の木々が揺れ始め、花びらが舞い踊り、満月が天頂に達した。",
        bg: "bg11",
        speed: 0.4,
        audio: "moon.m4a", // 🎵 音声変更ポイント1
        lines: 2
    },
    { clear: true },
    {
        text: "その時・・・。",
        bg: "bg11",
        speed: 0.2,
        audio: "moon.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "まばゆい光がRYOCHANを包み込んだ・・・。",
        bg: "bg11",
        speed: 0.2,
        audio: "moon.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "それは普通の月光ではなかった。\n青白く、まるで生きているように脈動していた。",
        bg: "bg2",
        speed: 0.4,
        audio: "moon.m4a", // シーンスキップ対応
        lines: 2,
        scene: "scene2",
        sceneTitle: "月光の力"
    },
    {
        text: "RYOCHANの体が震え、鎧の隙間から青い光が漏れ始め\nゆっくりと、その瞳が開いた・・・",
        bg: "bg2",
        speed: 0.3,
        audio: "moon.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        speaker: "RYOCHAN",
        text: "うう・・・ここは・・・どこだ・・・？",
        bg: "bg2",
        speed: 0.1,
        audio: "moon.m4a", // シーンスキップ対応
        lines: 1
    },
    { clear: true },
    {
        text: "RYOCHANは混乱し辺りを見回した。\n・・・見知らぬ神社のようだ。",
        bg: "bg2",
        speed: 0.4,
        audio: "moon.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "いつの間にか散り始めた桜の花びら。\nそして体の内側から湧き上がる不思議な温かさ。",
        bg: "bg2",
        speed: 0.4,
        audio: "moon.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        speaker: "RYOCHAN",
        text: "なぜ・・・おいらはここに・・・？",
        bg: "bg2",
        speed: 0.2,
        audio: "moon.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "答える者はおらず。ただ桜の花びらが舞い続けるだけだった。",
        bg: "bg2",
        speed: 0.4,
        audio: "moon.m4a", // シーンスキップ対応
        lines: 2
    },

    // ========== シーン3：老人の登場 ==========
    {
        text: "突然、花びらが集まり始め、渦を巻いた。\nその光の中から一人の老人が姿を現した。",
        bg: "bg8",
        speed: 0.4,
        audio: "oldman.m4a", // 🎵 音声変更ポイント2
        lines: 2,
        scene: "scene3",
        sceneTitle: "老人の登場",
    },
    {
        speaker: "OLD MAN",
        text: "長い眠りから目覚めたようじゃな、RYOCHAN。",
        bg: "bg8",
        speed: 0.3,
        lines: 2,
        audio: "oldman.m4a", // シーンスキップ対応
    },
    { clear: true },
    {
        text: "その声は深く響き、古い木の響きのようだった。\nRYOCHANは身構えた。",
        bg: "bg8",
        speed: 0.4,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        speaker: "RYOCHAN",
        text: "あなたは誰だ？どうしておいらの名前を・・・？",
        bg: "bg8",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "老人は優しく微笑んだ。",
        bg: "bg8",
        speed: 0.4,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 1
    },
    { clear: true },
    {
        speaker: "OLD MAN",
        text: "わしはこの神社の守り人。そして、おぬしを待っておったのじゃ。",
        bg: "bg8",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        speaker: "RYOCHAN",
        text: "待っていた？おいらを？",
        bg: "bg8",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "老人は月に向かって手を広げた。",
        bg: "bg3",
        speed: 0.4,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2,
        scene: "scene4",
        sceneTitle: "月光の力"
    },
    {
        speaker: "OLD MAN",
        text: "今夜は特別な夜じゃ。満月の力が最も強まる夜。",
        bg: "bg3",
        speed: 0.3,
        lines: 2,
        audio: "oldman.m4a", // シーンスキップ対応
    },
    {
        text: "そして、おぬしの中に眠る力が目醒める時。",
        bg: "bg3",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        speaker: "RYOCHAN",
        text: "力？おいらの中に？",
        bg: "bg3",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "老人は静かに語り始めた。",
        bg: "bg3",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 1
    },
    { clear: true },

    // ========== シーン5：氣の教え ==========
    {
        speaker: "OLD MAN",
        text: "日本には昔から『氣』という素晴らしい力があった。\n万物を繋ぐ力、生命に満ちた力じゃ。",
        bg: "bg4",
        speed: 0.3,
        lines: 2,
        scene: "scene5",
        sceneTitle: "氣の教え",
        audio: "oldman.m4a", // シーンスキップ対応
    },
    {
        text: "老人が杖を地面に打ち付けると、空中に『氣』の文字が青い光で浮かび上がった。",
        bg: "bg4",
        speed: 0.4,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        speaker: "OLD MAN",
        text: "この文字を見よ。『米』と『气』が組み合わさっておる。",
        bg: "bg4",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "大地の恵みと天のエネルギーが一つになった形じゃ。\n日本人は古くからこの力を感じ、共に生きてきた。",
        bg: "bg4",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "老人の表情が暗くなった。",
        bg: "bg4",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 1
    },
    {
        speaker: "OLD MAN",
        text: "しかし戦後、多くの文字が簡略化されてしまった。\n『氣』は『気』となり、その本質が失われた。",
        bg: "bg4",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "これは単なる文字の変化ではない。\n日本人の魂の一部が消されたのじゃ。",
        bg: "bg4",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "RYOCHANは静かに聞いていた。不思議なことに、老人が語る『氣』という言葉が、体の中で響いているのを感じていた。",
        bg: "bg4",
        speed: 0.4,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        speaker: "RYOCHAN",
        text: "それがおいらと何の関係が・・・？",
        bg: "bg4",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        speaker: "OLD MAN",
        text: "大いに関係がある。",
        bg: "bg4",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 1
    },
    {
        text: "老人の眼が光った。",
        bg: "bg4",
        speed: 0.4,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 1
    },
    { clear: true },
    {
        speaker: "OLD MAN",
        text: "おぬしは『氣』を視る力を持つ守護者として選ばれた。\n今夜、その力が覚醒したのじゃ。",
        bg: "bg4",
        speed: 0.3,
        audio: "oldman.m4a", // 🔥 重要：切り替え直前
        lines: 2
    },
    { clear: true },

    // ========== シーン6：覚醒の真実 ==========
    {
        text: "その瞬間、RYOCHANの視界が変わった。\n世界が違って見えた。",
        bg: "bg5",
        speed: 0.4,
        audio: "shadow1.m4a", // 🎵 音声変更ポイント3（重要！）
        lines: 2,
        scene: "scene6",
        sceneTitle: "覚醒の真実",
        audioSwitchForced: true // 🔥 強制切り替えフラグ
    },
    {
        text: "神社の周りに青い光の流れが見え、街の方向からは不吉な赤い線が伸びていた。",
        bg: "bg5",
        speed: 0.4,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        speaker: "RYOCHAN",
        text: "あれは・・・なんだ？",
        bg: "bg5",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "RYOCHANは街の方向を指差した。",
        bg: "bg5",
        speed: 0.4,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        speaker: "OLD MAN",
        text: "見えるじゃろう。あれが現代世界の悪しき『氣』じゃ。",
        bg: "bg5",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "様々な形を取って人々を脅かし、害をなそうとしておる。",
        bg: "bg5",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },

    // ========== シーン7：ブロックチェーンの脅威 ==========
    {
        text: "老人が杖を振ると、RYOCHANの心に映像が浮かんだ。\n暗い部屋でコンピューターに向かう人影。",
        bg: "bg6",
        speed: 0.4,
        lines: 2,
        scene: "scene7",
        sceneTitle: "ブロックチェーンの脅威",
        audio: "shadow1.m4a", // シーンスキップ対応
    },
    {
        text: "画面には複雑なコードが流れ、その周りに赤く邪悪な霧が渦巻いている。",
        bg: "bg6",
        speed: 0.4,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        speaker: "OLD MAN",
        text: "この者はブロックチェーンという新しい技術を悪用し、人々の資産を奪おうとしておる。",
        bg: "bg6",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "普通の目には見えんが、おぬしの目には見える。",
        bg: "bg6",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        speaker: "RYOCHAN",
        text: "ブロックチェーン？",
        bg: "bg6",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 1
    },
    {
        text: "RYOCHANには馴染みのない言葉だった。",
        bg: "bg6",
        speed: 0.4,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 1
    },
    { clear: true },

    // ========== シーン8：使命の説明 ==========
    {
        speaker: "OLD MAN",
        text: "未来を変える技術じゃ。しかし光があるところには闇もある。",
        bg: "bg4",
        speed: 0.3,
        lines: 2,
        scene: "scene8",
        sceneTitle: "使命の説明",
        audio: "shadow1.m4a", // シーンスキップ対応
    },
    {
        text: "おぬしの役目は、その闇を見つけ出し、暴き、人々をそれから守ることじゃ。",
        bg: "bg4",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "おぬしは古の知恵と新しい技術を繋ぐ架け橋なのじゃ。",
        bg: "bg4",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "RYOCHANは複雑な気持ちで街を見つめた。\n確かに、赤い『氣』の流れが見える。",
        bg: "bg5",
        speed: 0.4,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "そしてその向こうに潜む危険を感じ取ることができた。",
        bg: "bg5",
        speed: 0.4,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },

    // ========== シーン9：決意 ==========
    {
        speaker: "RYOCHAN",
        text: "でも・・・おいらに本当にそんなことができるのだろうか？",
        bg: "bg7",
        speed: 0.3,
        lines: 2,
        scene: "scene9",
        sceneTitle: "決意",
        audio: "shadow1.m4a", // シーンスキップ対応
    },
    {
        text: "老人は微笑んだ。",
        bg: "bg7",
        speed: 0.4,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 1
    },
    { clear: true },
    {
        speaker: "OLD MAN",
        text: "一人ではない。明日、おぬしはわしの孫娘に会うじゃろう。",
        bg: "bg7",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        speaker: "OLD MAN",
        text: "彼女はブロックチェーンの研究者じゃ。\nおぬしの力と彼女の技術が合わされば、真の守護が始まる。",
        bg: "bg7",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "RYOCHANは深く考えた。自分にしか見えないものがある",
        bg: "bg7",
        speed: 0.4,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "そしてその力で、多くの人を助けることができるかもしれない",
        bg: "bg7",
        speed: 0.4,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },

    // ========== シーン10：旅立ち ==========
    {
        speaker: "RYOCHAN",
        text: "わかった。やってみる。",
        bg: "bg7",
        speed: 0.3,
        lines: 2,
        scene: "scene10",
        sceneTitle: "旅立ち",
        audio: "shadow1.m4a", // シーンスキップ対応
    },
    {
        speaker: "OLD MAN",
        text: "『やってみる』ではない・・・『やるしかない』のじゃ！",
        bg: "bg7",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "勇気を持って吠え、名誉を持って噛みつくのじゃ！",
        bg: "bg7",
        speed: 0.3,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "RYOCHANは勇ましく吠えた！",
        bg: "bg7",
        speed: 0.4,
        audio: "shadow1.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: " 老人の顔に満足の表情が浮かんだ。",
        bg: "bg4",
        speed: 0.4,
        audio: "oldman.m4a", // 🎵 音声変更ポイント4
        lines: 2,
        audioSwitchForced: true // 🔥 強制切り替えフラグ
    },
    {
        speaker: "OLD MAN",
        text: "ありがとう、RYOCHAN。おぬしの旅はまだ始まったばかりじゃ。",
        bg: "bg4",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },

    // ========== シーン11：エピローグ ==========
    {
        text: "老人は桜の花びらとなって風に散り始めた。",
        bg: "bg8",
        speed: 0.4,
        lines: 2,
        scene: "scene11",
        sceneTitle: "エピローグ",
        audio: "oldman.m4a", // シーンスキップ対応
    },
    {
        speaker: "OLD MAN",
        text: "「サクラ」がおぬしを見つけるじゃろう",
        bg: "bg8",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "『氣』が二人を引き合せるのじゃ・・・",
        bg: "bg8",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "最後の言葉が風に消え、神社は元の静寂に戻った。",
        bg: "bg9",
        speed: 0.4,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "しかしRYOCHANの目に映る世界は変わったままだった。",
        bg: "bg9",
        speed: 0.4,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "その鎧は青く光り、瞳には決意が宿っていた。",
        bg: "bg9",
        speed: 0.4,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "RYOCHANは立ち上がり、街から立ち上る悪しき\n赤い『氣』を見つめた。",
        bg: "bg5",
        speed: 0.4,
        lines: 2,
        audio: "oldman.m4a", // シーンスキップ対応
    },
    {
        speaker: "RYOCHAN",
        text: "これがおいらの運命なら、受け入れよう。",
        bg: "bg5",
        speed: 0.3,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "RYOCHANにはあらゆる場所に流れる『氣』が見えていた。小さな足で、遠くの不吉なオーラに導かれながら神社の石段を駆け下りる。",
        bg: "bg5",
        speed: 0.4,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        text: "月明かりの下、その姿は闇に溶け込んでいった。",
        bg: "bg5",
        speed: 0.2,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "こうして『氣』の守護戦士、RYOCHANの冒険が始まった・・・。",
        bg: "bg5",
        speed: 0.2,
        audio: "oldman.m4a", // シーンスキップ対応
        lines: 2
    },
    { clear: true },
    {
        speaker: "？？？",
        text: "・・・。",
        bg: "bg10",
        speed: 0.2,
        lines: 2,
        audio: "shadow2.m4a", // 🎵 音声変更ポイント5
        scene: "scene12",
        sceneTitle: "謎の影",
        audioSwitchForced: true // 🔥 強制切り替えフラグ
    },
    {
        text: "面白い・・・。",
        bg: "bg10",
        speed: 0.2,
        lines: 2,
        audio: "shadow2.m4a", // シーンスキップ対応
    },
    {
        text: "我々が戦後７０年以上かけて弱体化させてきた\n日本の『氣』が",
        bg: "bg10",
        speed: 0.3,
        audio: "shadow2.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "一匹の犬によって復活しようとしているとはな・・・。",
        bg: "bg10",
        speed: 0.2,
        audio: "shadow2.m4a", // シーンスキップ対応
        lines: 2
    },
    {
        text: "<span class='emphasis'>つづく・・・</span>",
        bg: "bg10",
        speed: 0.4,
        audio: "shadow2.m4a", // シーンスキップ対応
        lines: 2
    }
];

// ========== シーンマッピング構築 ==========
const buildSceneMap = () => {
    const sceneMap = {};
    const sceneList = [];

    storyContent.forEach((content, index) => {
        if (content.scene) {
            const sceneInfo = {
                id: content.scene,
                title: content.sceneTitle || content.scene,
                startIndex: index,
                audio: content.audio || null
            };
            sceneMap[content.scene] = sceneInfo;
            sceneList.push(sceneInfo);
        }
    });

    return { sceneMap, sceneList };
};

console.log('✅ [storyContent] 日本語版ストーリーコンテンツ（音声切り替えデバッグ強化版）読み込み完了！');
console.log('📊 [storyContent] 総アイテム数:', storyContent.length);
console.log('🎬 [storyContent] シーンマッピング準備完了');
console.log('🎵 [storyContent] 強制音声切り替えポイント設定完了');